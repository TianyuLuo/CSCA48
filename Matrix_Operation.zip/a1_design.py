class Matrix():
    '''A class that represent Matrices'''
    def __init__(self, num_of_rows = 0, num_of_columns = 0):
        ''' (Matrix, int, int) -> NoneType
        Initialize a Matrix with its rows and columns be decided and
        represented as dictionary where the keys are the rank of rows
        and each value of a key is the content of each row.
        REQ: 0 <= num_of_rows
        REQ: 0 <= num_of_columns
        REQ: the number of value of each key should be equal to num_of_column.
        '''
        pass
    
    def set_row(self, rank_row, content):
        ''' (Matrix, int, list of int or str) -> NoneType
        Set the selected row according the rank_row with content.
        REQ: 1 <= rank_row
        '''
        pass

    def get_row(self, rank_row, content):
        ''' (Matrix, int, list of int or str) -> list of str or int
        Return corresponding content of selected row which is represented as
        a list.
        REQ: 1 <= rank_row
        '''
        pass
    
    def set_column(self, rank_column, content):
        ''' (Matrix, int, list of str or int) -> NoneType
        Set the selected column according to the rank_column with content.
        REQ: 1 <= rank_column
        '''
        pass
    
    def get_column(self, rank_column):
        ''' (Matrix, int) -> list of str or int
        Return corresponding content of the selected column which is represented
        as a list.
        REQ: 1 <= rank_column
        '''
        pass
    
    def get_value(self, row, column):
        ''' (Matrix, int, int) -> int or str
        Return a single item according to the row and column we choose
        REQ: 0 <= row
        REQ: 0 <= column
        '''
        pass
    
    def set_value(self, row, column, obj):
        ''' (Matrix, int, int, int or str) -> NoneType
        Replace a single item according to the row and column we choose by item.
        REQ: 0 <= row
        REQ: 0 <= column
        '''
        pass
        
    def swap_columns(self, column_1, column_2):
        ''' (Matrix, int, int) -> NoneType
        Swap the two column we choose.
        REQ: 0 <= column_1
        REQ: 0 <= column_2
        '''
        
    def swap_rows(self, row_1, row_2):
        ''' (Matrix, int, int) -> NoneType
        Swap the two rows we choose.
        REQ: 0 <= row_1
        REQ: 0 <= row_2
        '''
    
    def get_transpose(self):
        ''' (Matrix) -> Matrix
        Return a Matrix that is the transpose of the original matrix.
        '''
        pass
    
    def Add(self, add_matrix):
        ''' (Matrix, Matrix) -> NoneType
        Return Add a new matrx which is the sum of two matrices
        REQ: the size of the add_matrix should be equal to the original one.
        REQ: the add_matrix can have either strings or floats as its entries.
        '''
        pass
    
    def Multiply(self, multiply_obj):
        ''' (Matrix, Matrix) -> NoneType
        Return a new Matrix which is the product of Multiply by the other two.
        REQ: the multiply_obj should be either a number or a Matrix that has
        number as its entries.
        REQ: if multiply_obj is a Matrix, then the number of the row of the
        multiply_obj should be equal to the number of the column of the original
        Matrix.
        '''
        pass
    
    def Subtract(self, subtract_matrix):
        ''' (Matrix, Matrix) -> NoneType
        Return a new_matrix that which is the difference of two matrices.
        REQ: the size of the subtract_matrix should be equal to the original
        one.
        REQ: the subtract_matrix should have numbers as its entries.
        '''
        pass


class One_D_Matrix(Matrix):
    '''A class that represent the one dimensional matrices'''
    def __init__(self, num_of_item, column):
        ''' (One_D_Matrix, int, str) -> NoneType 
        Initialize a new One_D_Matrix that represented as a dictionary where
        the key is 1 and the value is the content of the one dimensional matrix.
        REQ: 0 <= num_of_item
        REQ: column must be 'R' which represents the column vector or 'C' which
        represents the row vector.
        '''
        pass
    
    def get_1d_value(self, rank):
        ''' (One_D_Matrix, int) -> str or int
        Return an item that is retrived from the one dimensional matrix.
        REQ: 0 <= rank
        '''
        pass
    
    def set_1d_value(self, rank, obj):
        ''' (One_D_Matrix, int, str or int) -> NoneType
        Replace the item we choose according to the rank of it by obj
        REQ: 0 <= rank
        '''


class Square_Matrix(Matrix):
    '''A class that represent square matrices'''
    def __init__(self, size):
        ''' (Square_Matrix, int) -> NoneType
        Initialize a new Square_Matrix represented as a dictionary where the
        keys begining at 1 and ending at size are the rank of rows and
        the values of each keys are the content of each row.
        REQ: 0 <= size
        REQ: the number of the value of each key should be equal to num_of_item.
        '''
        pass
    

class two_by_two_Matrix(Square_Matrix):
    '''A class that represent 2*2 Matrices'''
    def __init__(self):
        ''' (two_by_two_Matrix) -> NoneType
        Initialize a new two_by_two_Matrix represented as a dictionary where
        keys are the number of rows and values of each key are content of
        the row.'''
        pass
    
    def get_determinant(self):
        ''' (Square_Matrix) -> int
        Return a value that is the determinant of the Square_Matrix
        '''
        pass


class Identity_Matrix(Square_Matrix):
    '''A class that represent identity matrices'''
    def __init__(self, size):
        ''' (Identity_Matrix, int or str) -> NoneType
        Initialize a new Identity_Matrix represented as dictionary by using
        Square_Matrix __init__.
        '''
        pass
    
    def set_identity_value(self, value):
        ''' (Identity_Matrix, int or str) -> NoneType
        Set the value of the identity Matrix.
        '''
        pass


class ValueNotDefined(Exception):
    '''An exception that raises when the entries user selected from Matrices
    does not exist in the set Matrix.
    '''
    pass


class ColumnNotDefined(Exception):
    '''An exception that raises when the columns user selected from Matrices
    does not exist.
    '''
    pass


class RowNotDefined(Exception):
    '''An exception that raises when the column user selected from Matrices
    does not exist.
    '''
    pass


class ValueNotSet(Exception):
    ''' An eception that raises when using get_value to get a specifc number at
    a specific place where the value is not being set in Matrix.'''
    pass