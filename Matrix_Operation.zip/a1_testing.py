import unittest
from a1_design import *

def set_Matrix_helper(row, column, cont):
    ''' (int, int, list of str or int) -> Matrix
    Return a set Matrix with the same content of row when the testcase needs to
    set a Matrix with strings or numbers.
    REQ: the type of the elment in content must be consistent.
    REQ: len(cont) = column
    '''
    matrix = Matrix(row, column)
    for i in range(row):
        matrix.set_row(i, cont)
    return matrix


def set_Square_Matrix_helper(size, cont):
    ''' (int, list of int or str) -> Square_Matrix
    Return a set Square_Matrix with the same content of row when the testcase
    needs to set a Square_Matrix with strings or numbers.
    REQ: the type of the elment in content must be consistent
    '''
    matrix = Square_Matrix(size)
    for i in range(size):
        matrix.set_row(i, cont)
    return matrix


def set_One_D_Matrix_helper(size, cont):
    ''' (int, list of str or int) -> One_D_Matrix
    Return a set One_D_Matrix when the testcase needs to set a One_D_Matrix
    with strings or numbers.
    REQ: the type of the elment in content must be consistent
    '''
    matrix = One_D_Matrix(size, column)
    for i in range(size):
        matrix.set_1d_value(cont[i])
    return matrix
    
    
def set_two_by_two_Matrix_helper(cont):
    ''' (list of int or str) -> two_by_two_Matrix
    Return a set 2*2 two_by_two_Matrix with the same content of row
    when the testcase needs to set a two_by_two_Matrix
    REQ: the type of the elment in content must be consistent.
    '''
    matrix = two_by_two_Matrix()
    for i in range(2):
        matrix.set_row(i, cont)
    return matrix
        

class TestMatrixInitialization(unittest.TestCase):
    def test_Matrix_initialization(self):
        matrix = Matrix(2, 3)
        self.assertEqual(type(matrix) == Matrix, True, 
                         'Fail to initialize Matrix')


class TestMatrixGetRowAndSetRowMethods(unittest.TestCase):
    def test_get_row_and_set_row_work_with_Matrix_with_number(self):
        # each row's content
        cont = [1, 2, 3]
        # create a 2*3 Matrix with cont
        test_matrix = set_Matrix_helper(2, 3, cont)
        # select a row to be gotten
        rank_row = 1
        # find out whether the selected row's content = cont
        self.assertEqual(test_matrix.get_row(rank_row) == cont, True, 
                         'Fail to set or get row with number')       
    
    def test_get_row_and_set_row_work_with_Matrix_with_strings(self):
        cont = ['a', 'b', 'c']
        test_matrix = set_Matrix_helper(2, 3, cont)
        rank_row = 1
        self.assertEqual(test_matrix.get_row(rank_row) == cont, True, 
                         'Fail to get row or set row with strings')
        
    def test_get_row_and_set_row_work_with_Matrix_with_Square_Matrix(self):
        cont1 = [1, 2 ,3]
        cont2 = ['a', 'b', 'c']
        test_matrix_1 = set_Square_Matrix_helper(3, cont1)
        test_matrix_2 = set_Square_Matrix_helper(3, cont2)
        rank_row = 1
        self.asserEqual(test_matrix_1.get_row(rank_row) == cont1 and 
                        test_matrix_2.get_row(rank_row) == cont2, True, 
                        'Fail to set or get row with Square_Matrix')
        
    def test_get_row_and_set_row_works_with_two_by_two_Matrix(self):
        cont1 = [1, 2]
        cont2 = ['a', 'b']
        test_matrix_1 = set_Matrix_helper(cont1)
        test_matrix_2 = set_Matrix_helper(cont2)
        rank_row = 1
        self.asserEqual(test_matrix_1.get_column(rank_row) == cont1 and
                        test_matrix_2.get_column(rank_row) == cont2, True,
                        'Fail to set or get row with the two_by_two_Matrix')

    
class TestMatrixGetValueAndSetValueMethods(unittest.TestCase):
    def test_get_value_and_set_value_methods_work_with_number(self):
        test_matrix = Matrix(2, 2)
        test_matrix.set_value(1, 2, 1)
        target = test_matrix.get_value(1, 2)
        self.assertEqual(target, 1, 'Failed to set or get the number')
        
    def test_get_value_and_set_value_methods_work_with_string(self):
        test_matrix = Matrix(2, 2)
        test_matrix.set_value(1, 2, 'banana')
        target = test_matrix.get_value(1, 2)
        self.assertEqual(target, 'banana', 'Fail to set or get the string')
    
    def test_get_value_and_set_value_methods_work_with_Square_Matrix(self):
        test_matrix_1 = Square_Matrix(2)
        test_matrix_2 = Square_Matrix(2)
        cont_1 = 1
        cont_2 = 'a'
        test_matrix_1.set_value(1, 1, cont_1)
        test_matrix_2.set_value(1, 1, cont_2)
        self.assertEqual(test_matrix_1.get_value(1, 1) == cont_1 and 
                         test_matrix_2.get_value(1, 1) == cont_2, True, 
                         'Fail to get or set value in Square_Matrix')

    def test_get_value_and_set_value_methods_work_with_two_by_two_Matrix(self):
        test_matrix_1 = two_by_two_Matrix()
        cont_1 = 1
        test_matrix_1.set_value(1, cont_1)
        test_matrix_2 = two_by_two_Matrix(2)
        cont_2 = 'a'
        test_matrix_2.set_value(1, cont_2)
        self.assertEqual(test_matrix_1.get_value(1) == cont_1 and 
                         test_matrix_2.get_value(1) == cont_2, True, 
                         'Fail to get or set value in two_by_two_Matrix')


class TestMatrixSwapColumn(unittest.TestCase):
    def test_swap_columns_works_with_Matrix_with_exist_columns(self):
        test_matrix = Matrix(3, 2)
        column_1 = [1, 2, 3]
        column_2 = [4, 5, 6]
        test_matrix.set_column(1, column_1)
        test_maitrx.set_column(2, column_2)
        test_matrix.swap_columns(1, 2)
        self.assertEqual(test_matrix.get_column(2) == column_1 and 
                         test_matrix.get_column(1) == column_2, True, 
                         'Fail to swap columns with Matrix')
    
    def test_swap_columns_works_with_Square_Matrix(self):
        test_matrix = Square_matrix(2)
        column_1 = [3, 4]
        column_2 = [6, 8]
        test_matrix.set_column(1, column_1)
        test_matrix.set_column(2, column_2)
        test_matrix.swap_columns(1, 2)
        self.assertEqual(test_matrix.get_column(2) == column_1 and 
                         test_matrix.get_column(1) == column_2, True, 
                         'Fail to swap columns with Square Matrix')
    
    def test_swap_columns_works_with_two_by_Matrix(self):
        test_matrix = two_by_two_Matrix()
        column_1 = [3, 4]
        column_2 = [6, 8]
        test_matrix.set_column(1, column_1)
        test_matrix.set_column(2, column_2)
        test_matrix.swap_columns(1, 2)
        self.assertEqual(test_matrix.get_column(2) == column_1 and 
                         test_matrix.get_column(1) == column_2, True, 
                         'Fail to swap columns with Square Matrix')
    
    def test_swap_columns_works_with_identity_Matrix(self):
        test_matrix = Identity_Matrix(3)
        value = 4
        test_matrix.set_identity_value(value)
        column_1 = [value, 0, 0]
        column_2 = [0, value, 0]
        test_matrix.swap_columns(1, 2)
        self.assertEqual(test_matrix.get_column(2) == column_1 and 
                         test_matrix.get_column(1) == column_2, True, 
                         'Fail to swap columns with Identity Matrix')
        

class TestMatrixSwapRows(unittest.TestCase):
    def test_swap_rows_works_with_Matrix_with_exist_row(self):
        test_matrix = Matrix(2, 3)
        row_1 = [2, 5, 7]
        row_2 = [4, 1, 8]
        test_matrix.set_row(1, row_1)
        test_matrix.set_row(2, row_2)
        test_matrix.swap_rows(1, 2)
        self.assertEqual(test_matrix.get_row(1) == row_2 and 
                         test_matrix.get_row(2) == row_1, True, 
                         'Fail to swap rows with Matrix')

    def test_swap_rows_works_with_Square_Matrix(self):
        test_matrix = Square_Matrix(2)
        row_1 = [2, 5]
        row_2 = [4, 1]
        test_matrix.set_row(1, row_1)
        test_matrix.set_row(2, row_2)
        test_matrix.swap_rows(1, 2)
        self.assertEqual(test_matrix.get_row(1) == row_2 and 
                         test_matrix.get_row(2) == row_1, True, 
                         'Fail to swap rows with Squatr_Matrix')
    
    def test_swap_rows_works_with_two_by_two_Matrix(self):
        test_matrix = two_by_two_Matrix()
        row_1 = [2, 5]
        row_2 = [4, 1]
        test_matrix.set_row(1, row_1)
        test_matrix.set_row(2, row_2)
        test_matrix.swap_rows(1, 2)
        self.assertEqual(test_matrix.get_row(1) == row_2 and 
                         test_matrix.get_row(2) == row_1, True, 
                         'Fail to swap rows with two_by_two_Matrix') 
        
    def test_swap_rows_works_with_Identity_Matrix(self):
        test_matrix = Identity_Matrix(4)
        row_1 = [4, 0, 0]
        row_2 = [0, 4, 0]
        test_matrix.swap_rows(1, 2)
        self.assertEqual(test_matrix.get_row(2) == row_1 and 
                         test_matrix.get_row(1) == row_2, True, 
                         'Fail to swap rows with Identity Matrix')        


class TestMatrixAdd(unittest.TestCase):
    def test_Add_works_with_Matrix_numbers(self):
        cont_1 = [1, 2, 3]
        cont_2 = [4, 5, 6]
        sum_row= []
        for i in range(len(cont_1)):
            sum_row_1.append(cont_1[i] + cont_2[i])
        test_matrix_1 = set_Matrix_helper(2, 3, cont_1)
        test_matrix_2 = set_Matrix_helper(2, 3, cont_2)
        matrix = test_matrix_1.Add(test_matrix_2)
        self.assertEqual(matrix.get_row(1) == sum_row_1 and
                         matrix.get_row(2), True,
                         'Fail to find Matrix with numbers')

    def test_Add_works_with_Matrix_strings(self):
        cont_1 = ['a', 'b', 'c']
        cont_2 = ['d', 'e', 'g']
        sum_row_1 = []
        for i in range(len(cont_1)):
            sum_row_1.append(cont_1[i] + cont_2[i])
        test_matrix_1 = set_Matrix_helper(2, 3, cont_1)
        test_matrix_2 = set_Matrix_helper(2, 3, cont_2)
        matrix = test_matrix_1.Add(test_matrix_2)
        self.assertEqual(matrix.get_row(1) == sum_row_1 and
                         matrix.get_row(2) == sum_row_1, True,
                         'Fail to Add Matrices with strings')

    def test_Add_works_with_Square_Matrix(self):
        cont_1 = [1, 2]
        cont_2 = [3, 5]
        sum_row_1 = []
        for i in range(len(cont_1)):
            sum_row_1.append(cont_1[i] + cont_2[i])
        test_matrix_1 = set_Square_Matrix_helper(2, cont_1)
        test_matrix_2 = set_Square_Matrix_helper(2, cont_2)
        matrix = test_matrix_1.Add(test_matrix_2)
        self.assertEqual(matrix.get_row(1) == sum_row_1 and 
                         matrix.get_row(2) == sum_row_1, True,
                         'Fail to Add Square Matrices')
        
    def test_Add_works_with_One_D_Matrix(self):
        # set two one_d_matrices with 3 items
        length = 3
        cont = [1, 3, 4]
        test_matrix_1 = One_D_Matrix(length, cont)
        test_matrix_2 = One_D_Matrix(length, cont)
        # Add test_matrix_2 to the test_matrix_1
        matrix_3 = test_matrix_1.Add(test_matrix_2)
        # get test_matrix_1's value after addition
        matrix_sum = []
        for i in range(length):
            matrix_sum.append(matrix_3.get_1d_value(i))
        # illustrate the expected sum
        expected_sum = []
        for i in range(length):
            expected_sum.append(cont[i] + cont[i])
        self.assertEqual(matrix_sum == expected_sum, True,
                         'Fail to Add the One_D_Matrix')
        
    def test_Add_works_with_two_by_two_Matrix(self):
        cont_1 = [1, 2]
        cont_2 = [3, 5]
        sum_row_1 = []
        for i in range(len(cont_1)):
            sum_row_1.append(cont_1[i] + cont_2[i])
        test_matrix_1 = set_two_by_two_Matrix_helper(cont_1)
        test_matrix_2 = set_two_by_two_Matrix_helper(cont_2)
        matrix_3 = test_matrix_1.Add(test_matrix_2)
        self.assertEqual(matrix_3.get_row(1) == sum_row_1 and
                         matrix_3.get_row(2) == sum_row_1, True,
                         'Fail to Add two_by_two Matrices')

    def test_Add_works_with_Identity_Matrix(self):
        value = 4
        size = 2
        test_matrix_1 = Identity_Matrix(size)
        test_martix_2 = Identity_Matrix(size)
        test_matrix_1.set_identity_value(value)
        test_matrix_2.set_identity_value(value)
        test_matrix_1.Add(test_matrix_2)
        # get the first row of test_matrix_1 and test_matrix_2
        test_m_1_row_1 = []
        for i in range(size):
            test_m_1_row_1.append(0)
        test_m_1_row_1[0] = 4
        test_m_2_row_1 = test_m_1_row_1[:]
        # get the row_1 after addition
        sum_row_1 = []
        for i in range(size):
            sum_row_1.append(test_m_2_row_1[i] + test_m_1_row_1[i])
        self.assertEqual(test_matrix_1.get_row(1) == sum_row_1, True,
                         'Fail to add between identity matrices')


class TestMatrixMultiply(unittest.TestCase):
    def test_Multiply_works_between_Matrices(self):
        cont1 = [1, 2]
        cont2 = [1, 2, 4]
        matrix_1 = set_Matrix_helper(2, 2, cont1)
        matrix_2 = set_Matrix_helper(2, 3, cont2)
        matrix3 = test_matrix_1.Multiply(matrix_2)
        m2_column_1 = matrix_2.get_column(1)
        m3_row_1 = []
        for i in range(len(cont1)):
            m3_row_1.append(cont1[i] * m2_column_1[i])
        self.assertEqual(matrix3.get_row(1) == m3_row_1, True, 
                         'Fail to Multiply between Matrices')
    
    def test_Multiply_works_between_scalar_and_matrix(self):
        cont = [2, 2]
        test_matrix_1 = set_Matrix_helper(2, 2, 2)
        scalar = 1
        Matrix3 = test_matrix_2.Multiply(1)
        self.assertEqual(Matrix3.get_row(1) == cont and 
                         Matrix3.get_row(2) == cont, True,
                         'Fail to Multiply between Matrix and scalar')
        
    def test_Multiply_works_with_One_D_Matrix(self):
        matrix_1 = One_D_Matrix(2, column)
        matrix_2 = One_D_Matrix(2, row)
        matrix_1.set_1d_value(1, 2)
        matrix_1.set_1d_value(2, 3)
        matrix_2.set_1d_value(1, 4)
        matrix_2.set_1d_value(2, 4)
        matrix_3 = matrix_1.Multiply(matrix_2)
        self.assert_Equal(matrix_3.get_value(1) == 8 and
                          matrix_3.get_value(2) == 12, True)

    def test_Multiply_works_with_Square_Matrix(self):
        cont_1 = [1, 2]
        cont_2 = [2, 1]
        test_matrix_1 = set_Square_Matrix_helper('N', cont_1)
        test_matrix_2 = set_Square_Matrix_helper('N', cont_2)
        matrix_3 = test_matrix_1.Multiply(test_matrix_2)
        self.assertEqual(matrix_3.get_row(1) == [6, 3], True,
                         'Fail to Multiply Square Matrices')

    def test_Multiply_works_with_two_by_two_Matrix(self):
        cont_1 = [1, 2]
        cont_2 = [2, 1]
        test_matrix_1 = set_two_by_two_Matrix_helper('N', cont_1)
        test_matrix_2 = set_two_by_two_Matrix_helper('N', cont_2)
        matrix_3 = test_matrix_1.Multiply(test_matrix_2)
        self.assertEqual(matrix_3.get_row(1) == [6, 3], True,
                         'Fail to Multiply two by two Matrices')        

    def test_Multiply_works_with_Identity_Matrix(self):
        matrix_1 = Identity_Matrix(2)
        matrix_2 = Identity_Matrix(2)
        matrix_1.set_Identity_value(1)
        matrix_1.set_Identity_value(2)
        matrix_3 = matrix_1.Multiply(matrix_2)
        self.assertEqual(matrix_3.get_row(1) == [2, 0] and 
                         matrix_3.get_row(2) == [0, 2], True, 
                         'Fail to multiply Identity Matrix')


class TestMatrixSubtract(unittest.TestCase):
    def test_Subtract_works_with_Matrix(self):
        row_1 = [1, 2, 1]
        row_2 = [1, 1 ,4]
        matrix_1 = set_Matrix_helper('N', row_1)
        matrix_2 = set_Matrix_helper('N', row_2)
        matrix_2.set_row(2, row_2)
        matrix_3 = matrix_1.Subtract(matrix_2)
        difference = []
        for i in range(len(row_1)):
            difference.append(row_1[i] - row_2[i])
        self.assertEqual(matrix_3.get_row(1) == difference, True,
                         'Fail to subtract between Matrices')
        
    def test_Subtract_works_with_One_D_Matrix(self):
        matrix_1 = One_D_Matrix(3, column)
        matrix_2 = One_D_Matrix(3, column)
        cont = [1, 2, 3]
        matrix_1.set_column(1, cont)
        matrix_2.set_column(1, cont)
        matrix_3 = matrix_1.Subtract(matrix_2)
        difference = []
        for i in range(len(row_1)):
            difference.append(cont[i] - cont[i])
        self.assertEqual(matrix_3.get_column(1) == cont, True, 
                         'Fail to Subtract between One_D_Matrix')
        
    def test_Subtract_works_with_Square_Matrix(self):
        row_1 = [1, 4, 5]
        size = 2
        matrix_1 = set_Square_Matrix_helper(size, cont_1)
        row_2 = [5, 6, 7]
        matrix_2 = set_Square_Matrix_helper(size, cont_2)
        matrix_3 = matrix_1.Subtract(matrix_2)
        difference = []
        for i in range(i):
            difference.Subtract(cont_1[i] - cont_2[i])
        self.assertEqual(matrix_3.get_row(1) == difference, True,
                        'Fail to Subtract between Square Matrices')

    def test_Subtract_works_with_two_by_two_Matrix(self):
        row_1 = [1, 4, 5]
        size = 2
        matrix_1 = set_two_bu_two_Matrix_helper(size, cont_1)
        row_2 = [5, 6, 7]
        matrix_2 = set_two_bu_two_Matrix_helper(size, cont_2)
        matrix_3 = matrix_1.Subtract(matrix_2)
        difference = []
        for i in range(i):
            difference.Subtract(cont_1[i] - cont_2[i])
        self.assertEqual(matrix_3.get_row(1) == difference, True,
                        'Fail to Subtract between two by two Matrices')

    def test_Subtract_works_with_Identity_Matrix(self):
        size = 2
        value = 3
        matrix_1 = Identity_Matrix(size)
        matrix_2 = Identity_Matrix(size)
        matrix_1.set_identity_value(value)
        matrix_2.set_identity_value(value)
        matrix_3 = matrix_2.Subtract(matrix_1)
        difference = []
        for i in range(size):
            difference.append(0)
        self.assertEqual(matrix_3.get_row(1) == difference and
                         matrix_3.get_row(2) == differecne, True, 
                         'Fail to Subtract between identity Matrices')
    

class Test1DMatrixInitialization(unittest.TestCase):
    def test_One_D_Matrix_Initializaion(self):
        matrix = One_D_Matrix(2, 'C')
        self.assertEqual(type(matrix) == One_D_Matrix, True, 
                         'Fail to initialize a new One_D_Matrix')


class TestGet1DValueAndSet1DValue(unittest.TestCase):
    def test_get_and_set_1d_value_methods_works_with_numbers(self):
        matrix = One_D_Matrix(2, 'R')
        value = 1
        matrix.set_1d_value(1, value)
        self.assertEqual(matrix.get_1d_value(1) == value, True,
                         'Fail to set or get the value of One_D_Matrix')
        
    def test_get_and_set_1d_value_methods_works_with_strings(self):
        matrix = One_D_Matrix(2, 'R')
        value = 'a'
        matrix.set_1d_value(1, value)
        self.assertEqual(matrix.get_1d_value(1) == value, True,
                         'Fail to set or get the value of One_D_Matrix')


class TestSquareMatrixInit(unittest.TestCase):
    def test_Square_Matrix_init_(self):
        matrix = Square_Matrix(2)
        self.assertEqual(type(matrix) == Square_Matrix, True,
                         'Fail to initialize a Square_Matrix')


class TestTwoByTwoMatrixInit(unittest.TestCase):
    def test_two_by_two_Matrix_init_(self):
        matrix = two_by_two_Matrix()
        self.assertEqual(type(matrix) == two_by_two_Matric, True,
                         'Fail to initialize a two_by_two Matrix')
    

class TestTwoByTwoMatrixGetDeterminant(unittest.TestCase):
    def test_two_by_two_Matrix_get_determinant(self):
        value1 = 1
        value2 = 3
        cont = [value1, value2]
        matrix = set_two_by_two_Matrix(cont)
        determinant = value1 * value2 - value2 * value1
        self.assertEqual(matrix.get_determinant == determinant, True,
                         'Fail to get determinant')


class TestIdentityMatrixInit(unittest.TestCase):
    def test_Identity_Matrix_Init(self):
        matrix = Identity_Matrix(2)
        self.assertEqual(type(matrix) == Identity_Matrix, True,
                         'Fail to initialize an Identity Matrix')
    
    
class TestValueNotDefinedException(unittest.TestCase):
    def test_ValueNotDefined_works_with_get_value(self):
        test_matrix = Matrix(2, 2)
        target = test_matrix.get_value(3, 6)
        self.assertRaises(ValueNotDefined, target, 
                         'Fail to raise ValueNotDefined Exception')     
    
    def test_ValueNotDefined_works_with_set_value(self):
        test_matrix = Matrix(2,2)
        target = test_matrix.set_value(3,3)
        self.assertRaises(ValueNotDefined, target,
                         'Fail to raise ValueNotDefined Exception')
    
    def test_ValueNotDefined_works_with_get_1d_value(self):
        test_matrix = One_D_Matrix(3)
        self.assertRaises(ValueNotDefined, test_matrix.get_1d_value(4),
                         'Fail to raise ValueNotDefined Exception')
    
    def test_ValueNotDefined_works_with_set_1d_value(self):
        test_matrix = One_D_Matrix(3)
        self.assertRaises(ValueNotDefined, test_matrix.set_1d_value(4, 3),
                         'Fail to raise ValueNotDefined Exception')

    
class TestColumnNotDefinedException(unittest.TestCase):
    def test_ColumnNotDefined_works_with_swap_columns(self):
        test_matrix = Matrix(2, 2)
        self.assertRaises(ColumnNotDefined, test_matrix.swap_column(1, 4),
                         'Fail to raise ColumnNotDefined Exception')


class TestRowNotDefinedException(unittest.TestCase):
    def test_RowNotDefined_works_with_swap_rows(self):
        test_matrix = Matrix(2, 2)
        self.assertRaises(RowNotDefined, test_matrix.swap_rows(2, 5), 
                         'Fail to raise RowNotDefined Exception')

                
class TestValueNotSetException(unittest.TestCase):
    def test_ValueNotSet_works_with_get_value(self):
        test_matrix = Matrix(2, 3)
        target = test_matrix.get_value(2, 1)
        self.assertRaises(ValueNotSet, target, 
                          'Fail to raise ValueNotSet Exception')
        
unittest.main(exit = False)
        