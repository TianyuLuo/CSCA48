class MatrixIndexError(Exception):
    '''An attempt has been made to access an invalid index in this matrix'''


class MatrixDimensionError(Exception):
    '''An attempt has been made to perform an operation on this matrix which
    is not valid given its dimensions'''


class MatrixInvalidOperationError(Exception):
    '''An attempt was made to perform an operation on this matrix which is
    not valid given its type'''


class MatrixNode():
    '''A general node class for a matrix'''

    def __init__(self, contents, right=None, down=None):
        '''(MatrixNode, obj, MatrixNode, MatrixNode) -> NoneType
        Create a new node holding contents, that is linked to right
        and down in a matrix
        '''
        self._contents = contents
        self._right = right
        self._down = down
        self._row_index = None
        self._column_index = None

    def __str__(self):
        '''(MatrixNode) -> str
        Return the string representation of this node
        '''
        return str(self._contents)

    def get_contents(self):
        '''(MatrixNode) -> obj
        Return the contents of this node
        '''
        return self._contents

    def set_contents(self, new_contents):
        '''(MatrixNode, obj) -> NoneType
        Set the contents of this node to new_contents
        '''
        self._contents = new_contents

    def get_right(self):
        '''(MatrixNode) -> MatrixNode
        Return the node to the right of this one
        '''
        return self._right

    def set_right(self, new_node):
        '''(MatrixNode, MatrixNode) -> NoneType
        Set the new_node to be to the right of this one in the matrix
        '''
        self._right = new_node

    def get_down(self):
        '''(MatrixNode) -> MatrixNode
        Return the node below this one
        '''
        return self._down

    def set_down(self, new_node):
        '''(MatrixNode, MatrixNode) -> NoneType
        Set new_node to be below this one in the matrix
        '''
        self._down = new_node

    def get_row_index(self):
        return self._row_index

    def get_column_index(self):
        return self._column_index

    def set_row_index(self, i):
        ''' (MatrixNode, int, int) -> NoneType
        Set the row and column which are i and j of the MatrixNode.
        '''
        self._row_index = i

    def set_column_index(self, j):
        self._column_index = j


def find_row_coord(head, val):
    ''' (MatrixNode, int) -> (MatrixNode, MatrixNode)
    Return two matrixNode in the row coordinate matrixnode, one of which is the
    MatrixNode before our determined MatrixNode and the other one is the node
    after it
    '''
    curr = head
    if head.get_down() == None:
        return (None, None)
    else:
        while curr.get_down() != None and curr.get_down().get_contents() <= val:
            curr = curr.get_down()
    if curr.get_down() == None:
        return (curr, None)
    else:
        return (curr, curr.get_down())


def find_col_coord(head, val):
    ''' (MatrixNode, int) -> (MatrixNode, MatrixNode)
    Return two matrixNode, one of which is the MatrixNode before our determined
    MatrixNode and the other one is the node after it
    '''
    curr = head
    if head.get_right() == None:
        return (None, None)
    else:
        while (curr.get_right() != None and
               curr.get_right().get_contents() <= val):
            curr = curr.get_right()
    if curr.get_right() == None:
        return (curr, None)
    else:
        return (curr, curr.get_right())


def find_node_down(head, row_num):
    ''' (MatrixNode, int) -> (MatrixNode, MatrixNode)
    Return two matrixNode, one of which is the MatrixNode before our determined
    MatrixNode and the other one is the node after it
    '''
    curr = head
    if head.get_down() == None:
        return (None, None)
    else:
        while (curr.get_down() != None and
               curr.get_down().get_row_index() <= row_num):
            curr = curr.get_down()
    if curr.get_down() == None:
        return (curr, None)
    else:
        return (curr, curr.get_down())


def find_node_right(head, col_num):
    ''' (MatrixNode, int) -> (MatrixNode, MatrixNode)
    Return two matrixNode, one of which is the MatrixNode before our determined
    MatrixNode and the other one is the node after it'''    
    curr = head
    if head.get_right() == None:
        return (None, None)
    else:
        while (curr.get_right() != None and
               curr.get_right().get_column_index() <= col_num):
            curr = curr.get_right()
    if curr.get_right() == None:
        return (curr, None)
    else:
        return (curr, curr.get_right())


def get_dot_product(row, column):
    ''' (OneDimensionalMatrix, OneDimensionalMatrix) -> int
    Return the dot product of the row in Matrix and the column in its
    mult_matrix.
    '''
    dot_product = 0
    row_length = row.get_length()
    for i in range(row_length):
        item_sum  = row.get_item(i) * column.get_item(i)
        dot_product += item_sum
    return dot_product


class Matrix():
    '''A class to represent a mathematical matrix'''

    def __init__(self, m, n, default=0):
        '''(Matrix, int, int, float) -> NoneType
        Create a new m x n matrix with all values set to default
        '''
        self._head = MatrixNode(None)
        self._width = m
        self._length = n

    def get_val(self, i, j):
        '''(Matrix, int, int) -> float
        Return the value of m[i,j] for this matrix m
        '''
        default_val = 0
        curr = self._head
        if i > self._width - 1 or j > self._length - 1:
            raise MatrixIndexError
        # if it is a empty Matrix
        elif curr.get_down() == None and curr.get_right() == None:
            return default_val
        # if if is not an empty Matrix
        else:
            # loop stops till find the column
            while (curr.get_right() != None and
                   curr.get_right().get_contents() != j):
                curr = curr.get_right()
            # if the column not found, then raise the
            if curr.get_right() == None:
                return default_val
            # if the column exists
            else:
                curr = curr.get_right()
                # the loop stops till finding the row
                while ( curr.get_down() != None
                        and curr.get_down().get_row_index() != i):
                    curr = curr.get_down()
                # if the row not found
                if curr.get_down() == None:
                    num_rows = curr.get_row_index()
                    # if the number of rows is larger than the rank of aimed row
                    if self._width > i:
                        # then it is the unset value and return default value
                        return default_val
                    else:
                        raise MatrixIndexError
                # if the row found
                elif curr.get_down().get_row_index() == i:
                    # return the content of it
                    return curr.get_down().get_contents()

    def set_val(self, i, j, new_val):
        '''(Matrix, int, int, float) -> NoneType
        Set the value of m[i,j] to new_val for this matrix m
        '''
        new_node = MatrixNode(new_val)
        new_node.set_column_index(j)
        new_node.set_row_index(i)
        if i > self._width - 1 and j > self._length - 1:
            raise MatrixIndexError
        # if it is an empty matrix
        if self._head.get_down() == None and self._head.get_right() == None:
            # set new column and row 
            new_r_coord = MatrixNode(i)
            new_c_coord = MatrixNode(j)
            # let head point to them
            self._head.set_down(new_r_coord)
            self._head.set_right(new_c_coord)
            # let new coordinate nodes point to new_val
            new_r_coord.set_right(new_node)
            new_c_coord.set_down(new_node)
        # if it is not an empty matrix
        else:
            # find i'th row and j'th column
            (curr_col, curr_col_after) = find_col_coord(self._head, j)
            (curr_row, curr_row_after) = find_row_coord(self._head, i)
            # if j is at the begining of the column with default val
            if curr_col == None and curr_col_after != None:
                # create a new column and the head point to the coordinate node
                new_c_coord = MatrixNode(j)
                self._head.set_right(new_c_coord)
                # let coordinate node point to the new_val
                new_c_coord.set_down(new_node)
            # if j is at the end of the colmn with default val
            elif curr_col.get_contents() != j and curr_col_after == None:
                new_c_coord = MatrixNode(j)
                curr_col.set_right(new_c_coord)
                new_c_coord.set_down(new_node)
            # if j'th col with default value is at NEITHER the begining nor
            # the end.
            elif curr_col.get_contents() != j and curr_col_after != None:
                new_c_coord = MatrixNode(j)
                new_c_coord.set_right(curr_col.get_right())
                curr_col.set_right(new_c_coord)
                new_c_coord.set_down(new_node)
            # if j is at NEITHER the begining nor the end of the matrix and 
            # had been set before
            elif curr_col.get_contents() == j:
                (curr_i, curr_i_after) = find_node_down(curr_col, i)
                # if the node is at the begining of the i'th col
                if curr_i.get_row_index() == None and curr_i_after != None:
                    new_node.set_down(curr_col.get_down())
                    curr_col.set_down(new_node)
                # if the node is at the end of the i'th col
                elif curr_i.get_row_index() != i and curr_i_after == None:
                    curr_i.set_down(new_node)
                # if the node is at NEITHER the begining nor the end and had
                # NOT been set as default value
                elif curr_i.get_row_index() != i and curr_i_after != None:
                    new_node.set_down(curr_i.get_down())
                    curr_i.set_down(new_val)
                # if the node is at NEITHER the begining nor the end and has
                # has been set before
                elif curr_i.get_contents() == i:
                    curr_i.set_contents(new_val)
            # if i'th row is at the begining of the row with default val
            if curr_row == None and curr_row_after != None:
                # create a new row coordinate node
                new_r_coord = MatrixNode(i)
                self._head.set_down(new_r_coord)
                new_r_coord.set_right(new_node)
            # if i'th row is at the end of the row with default val
            elif curr_row.get_contents() != i and curr_row_after == None:
                new_r_coord = MatrixNode(i)
                curr_row.set_down(new_r_coord)
                new_r_coord.set_right(new_node)
            # if the i'th row with default value is at NEITHER the begining
            # nor the end.
            elif curr_row.get_contents() != i:
                new_r_coord = MatrixNode(i)
                curr_row.set_down(new_r_coord)
                new_r_coord.set_right(new_node)
            # if the i'th row is at NEITHER the begining nor the end and had
            # been set before
            elif curr_row.get_contents() == i:
                (curr_j, curr_j_after) = find_node_right(curr_row, j)
                # if the new_node is at the begining of the i'th row
                if curr_j.get_column_index() == None and curr_j_after != None:
                    new_node.set_right(curr_row.get_right())
                    curr_row.set_right(new_node)
                # if the new_node is at the end of the i'th row
                elif (curr_j.get_column_index() != j and
                      curr_j_after == None):
                    curr_j.set_right(new_node)
                # if the new_node is at NEITHER the end nor the begining of
                # the i'th row hasn't been set before
                elif (curr_j.get_column_index() != j and curr_j_after != None):
                    new_node.set_right(curr_j.get_right())
                    curr_j.set_right(new_node)
                # if the new_node is at NEITHER the begining nor the end of
                # the i'th row and had been set before
                elif curr_j.get_column_index() == j:
                    curr_j.set_contents(new_val)

    def get_row(self, row_num):
        '''(Matrix, int) -> OneDimensionalMatrix
        Return the row_num'th row of this matrix
        '''
        curr = self._head
        if row_num > self._width - 1:
            raise MatrixIndexError
        # find the row
        while (curr.get_down().get_contents() != row_num and
               curr.get_down() != None):
            curr = curr.get_down()
        new_matrix = OneDimensionalMatrix(1, self._length)
        # if does not find the row
        if curr.get_down() == None:
            return new_matrix
        # if the row found, then set the current node be the node that is
        # the coordinate node
        else:
            curr = curr.get_down()
        # create a row coordinate Node
        row_coordinate = MatrixNode(0)
        new_matrix_head = new_matrix.get_head()
        new_matrix_head.set_down(row_coordinate)
        row_coordinate.set_right(curr.get_right())
        # set several new columns coordinate
        while curr.get_right() != None:
            new_matrix_head.set_right(
                MatrixNode(curr.get_right().get_column_index()))
            col_coordinate = new_matrix_head.get_right()           
            col_coordinate.set_down(curr.get_right())            
            new_matrix_head = col_coordinate
            curr = curr.get_right()
        return new_matrix

    def set_row(self, row_num, new_row):
        '''(Matrix, int, OneDimensionalMatrix) -> NoneType
        Set the value of the row_num'th row of this matrix to those of new_row
        '''
        curr = new_row.get_head()
        # if the new_row is in the form of row vector
        if new_row.get_width() == 1: 
            while curr.get_right() != None:
                curr = curr.get_right()
                col = curr.get_down().get_column_index()
                cont = curr.get_down().get_contents()
                self.set_val(row_num, col, cont)  
        # if the new_row is in the form of column vector
        else:
            while curr.get_down() != None:
                # find the rank of the column in the 
                curr = curr.get_down()
                row = curr.get_right().get_row_index()
                cont = curr.get_right().get_contents()
                self.set_val(row_num, row, contents)
    
    def get_col(self, col_num):
        '''(Matrix, int) -> OneDimensionalMatrix
        Return the col_num'th column of this matrix
        '''
        if col_num > self._length - 1:
            raise MatrixIndexError
        curr = self._head
        while (curr.get_right() != None and
               curr.get_right().get_contents() != col_num):
            curr = curr.get_right()
        new_matrix = OneDimensionalMatrix(self._width, 1)
        new_matrix_head = new_matrix.get_head()
        if curr.get_right() == None:
            return new_matrix
        else:
            curr = curr.get_right()
            col_coordinate = MatrixNode(0)
            new_matrix_head.set_right(col_coordinate)
            col_coordinate.set_down(curr.get_down())
            while curr.get_down() != None:
                new_matrix_head.set_down(
                    MatrixNode(curr.get_down().get_row_index()))
                row_coordinate = new_matrix_head.get_down()
                row_coordinate.set_right(curr.get_down())
                new_matrix_head = row_coordinate
                curr = curr.get_down()
        return new_matrix

    def set_col(self, col_num, new_col):
        '''(Matrix, int, OneDimensionalMatrix) -> NoneType
        Set the value of the col_num'th column of this matrix to those of
        new_row
        '''
        curr = new_col.get_head()
        # if the new_col is in the form of row vector
        if new_col.get_width() == 1: 
            while curr.get_right() != None:
                curr = curr.get_right()
                col = curr.get_down().get_column_index()
                cont = curr.get_down().get_contents()
                self.set_val(col, col_num, cont)  
        # if the new_col is in the form of column vector
        else:
            while curr.get_down() != None:
                # find the rank of the column in the 
                curr = curr.get_down()
                row = curr.get_right().get_row_index()
                cont = curr.get_right().get_contents()
                self.set_val(row, col_num, cont)

    def swap_rows(self, i, j):
        '''(Matrix, int, int) -> NoneType
        Swap the values of rows i and j in this matrix
        '''
        orign_row_1 = self.get_row(i)
        orign_row_2 = self.get_row(j)
        self.set_row(i, orign_row_2)
        self.set_row(j, orign_row_1)

    def swap_cols(self, i, j):
        '''(Matrix, int, int) -> NoneType
        Swap the values of columns i and j in this matrix
        '''
        orign_col_1 = self.get_col(i)
        orign_col_2 = self.get_col(j)
        self.set_col(i, orign_col_2)
        self.set_col(j, orign_col_1)

    def add_scalar(self, add_value):
        '''(Matrix, float) -> NoneType
        Increase all values in this matrix by add_value
        '''
        default_val = 0
        for i in range(self._width):
            for j in range(self._length):
                if self.get_val(i, j) == default_val:
                    self.set_val(i, j, default_val + add_value)
                else:
                    self.set_val(i, j, self.get_val(i, j) + add_value)

    def subtract_scalar(self, sub_value):
        '''(Matrix, float) -> NoneType
        Decrease all values in this matrix by sub_value
        '''
        default_val = 0
        for i in range(self._width):
            for j in range(self._length):
                if self.get_val(i, j) == default_val:
                    self.set_val(i, j, default_val - sub_value)
                else:
                    self.set_val(i, j, self.get_val(i, j) - sub_value)

    def multiply_scalar(self, mult_value):
        '''(Matrix, float) -> NoneType
        Multiply all values in this matrix by mult_value
        '''
        curr = self._head
        while curr.get_right() != None:
            curr = curr.get_right()
            while curr.get_down() != None:
                curr = curr.get_down()
                curr.set_contents(curr.get_contents() * mult_value)

    def add_matrix(self, adder_matrix):
        '''(Matrix, Matrix) -> Matrix
        Return a new matrix that is the sum of this matrix and adder_matrix
        '''
        new_matrix = Matrix(self._width, self._length)
        if (self._length != adder_matrix.get_length() or
            self._width != adder_matrix.get_width()):
            raise MatrixDimensionError
        else:
            for i in range(self._width):
                for j in range(self._width):
                    val_1 = self.get_val(i, j)
                    val_2 = adder_matrix.get_val(i, j)
                    new_matrix.set_val(i, j, val_1 + val_2)
        return new_matrix

    def multiply_matrix(self, mult_matrix):
        '''(Matrix, Matrix) -> Matrix
        Return a new matrix that is the product of this matrix and mult_matrix
        '''
        if self._length != mult_matrix.get_width():
            raise MatrixDimensionError
        new_matrix = Matrix(self._width, mult_matrix.get_length())
        for i in range(self._width):
            for j in range(mult_matrix.get_length()):
                aimed_row = self.get_row(i)
                aimed_col = mult_matrix.get_col(j)
                dot_prd = get_dot_product(aimed_row, aimed_col)
                new_matrix.set_val(i, j, dot_prd)
        return new_matrix

    def get_head(self):
        '''(Matrix) -> MatrixNode
        Return the head of the Matrix
        '''
        return self._head

    def get_length(self):
        '''(Matrix) -> MatrixNode
        Return the number of the column in the Matrix
        '''
        return self._length
    
    def set_length(self, num_col):
        self._length = num_col
    
    def get_width(self):
        '''(Matrix) -> MatrixNode
        Return the number of the row in the Matrix
        '''
        return self._width
    
    def set_width(self, num_row):
        self._width = num_row


class OneDimensionalMatrix(Matrix):
    '''A 1xn or nx1 matrix.
    (For the purposes of multiplication, we assume it's 1xn)'''

    def get_item(self, i):
        '''(OneDimensionalMatrix, int) -> float
        Return the i'th item in this matrix
        '''
        if self._length == 1:
            return self.get_val(i, 0)
        elif self._width == 1:
            return self.get_val(0, i)
        else:
            raise MatrixInvalidOperationError

    def set_item(self, i, new_val):
        '''(OneDimensionalMatrix, int, float) -> NoneType
        Set the i'th item in this matrix to new_val
        '''
        if self._length == 1:
            return self.set_val(i, 0, new_val)
        elif self._width == 1:
            return self.set_val(0, i, new_val)
        else:
            raise MatrixInvalidOperationError


class SquareMatrix(Matrix):
    '''A matrix where the number of rows and columns are equal'''
    def transpose(self):
        '''(SquareMatrix) -> NoneType
        Transpose this matrix
        '''
        if self._length != self._width:
            raise MatrixInvalidOperationError
        if self._head.get_right() != None and self._head.get_down() != None:
            orign_col = self._head.get_right()
            orign_row = self._head.get_down()
            self._head.set_right(orign_row)
            self._head.set_down(orign_col)
            curr = self._head
            # reset the row_index and col_index in every matrixnode
            while curr.get_right() != None:
                curr = curr.get_right()
                curr_down = curr
                while curr_down.get_down() != None:
                    curr_down = curr_down.get_down()
                    orign_row_index = curr_down.get_row_index()
                    orign_col_index = curr_down.get_column_index()
                    curr_down.set_row_index(orign_col_index)
                    curr_down.set_column_index(orign_row_index)

    def get_diagonal(self):
        '''(Squarematrix) -> OneDimensionalMatrix
        Return a one dimensional matrix with the values of the diagonal
        of this matrix
        '''
        new_matrix = OneDimensionalMatrix(1, self._length)
        for i in range(self._length):
            if self.get_val(i, i) != 0:
                item = self.get_val(i, i)
                new_matrix.set_item(i, item)
        return new_matrix

    def set_diagonal(self, new_diagonal):
        '''(SquareMatrix, OneDimensionalMatrix) -> NoneType
        Set the values of the diagonal of this matrix to those of new_diagonal
        '''
        if new_diagonal.get_width() != self.get_width():
            raise MatrixInvalidOperation
        else:
            curr = new_diagonal.get_head()
            while curr.get_right() != None:
                curr = curr.get_right()
                row = curr.get_down().get_column_index()
                cont = curr.get_down().get_contents()
                self.set_val(row, row, cont)
            


class SymmetricMatrix(SquareMatrix):
    '''A Symmetric Matrix, where m[i, j] = m[j, i] for all i and j'''


class DiagonalMatrix(SquareMatrix, OneDimensionalMatrix):
    '''A square matrix with 0 values everywhere but the diagonal'''


class IdentityMatrix(DiagonalMatrix):
    '''A matrix with 1s on the diagonal and 0s everywhere else'''
    
    
if __name__ == '__main__':
    '''a = MatrixNode(1)
    b = MatrixNode(2)
    c = MatrixNode(3)
    d = MatrixNode(4)
    e = MatrixNode(5)
    f = MatrixNode(6)'''
    matrix1 = Matrix(2, 3)
    matrix1.set_val(0, 0,1)
    matrix1.set_val(0, 1, 2)
    matrix1.set_val(0, 2, 3)
    matrix1.set_val(1, 0 ,4)
    matrix1.set_val(1 ,1 ,5)
    matrix1.set_val(1, 2, 6)
    matrix2 = SquareMatrix(2, 2)
    matrix2.set_val(0, 0, 1)
    matrix2.set_val(1, 1, 1)
    matrix2.set_val(0,1, 4)
    matrix2.transpose()
    print(matrix2.get_val(1, 1))
    